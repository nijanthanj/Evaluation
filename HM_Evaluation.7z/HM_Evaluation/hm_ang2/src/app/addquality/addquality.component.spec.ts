import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AddqualityComponent } from './addquality.component';

describe('AddqualityComponent', () => {
  let component: AddqualityComponent;
  let fixture: ComponentFixture<AddqualityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AddqualityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddqualityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
