import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-addquality',
  templateUrl: './addquality.component.html',
  styleUrls: ['./addquality.component.css']
})
export class AddqualityComponent implements OnInit {

  @Input() qty; 

  constructor() { }

  ngOnInit() {
  }

}
