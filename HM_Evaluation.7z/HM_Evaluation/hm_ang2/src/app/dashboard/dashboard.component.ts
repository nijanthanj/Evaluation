import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  
  cartlists = [{
				    prod_desc: "Product 1",
				    qty: "1",
				    tot: "200 SEK"
				  },
				  {
				    prod_desc: "Product 2",
				    qty: "2",
				    tot: "200 SEK"
				  },
				  {
				    prod_desc: "Product 3",
				    qty: "2",
				    tot: "200 SEK"
				  }
				];
  constructor() { }

  ngOnInit() {
  }

}
