import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-productimage',
  templateUrl: './productimage.component.html',
  styleUrls: ['./productimage.component.css']
})
export class ProductimageComponent implements OnInit {
  
  @Input() imageSrc; 
  @Input() imageSize;

  constructor() { }

  ngOnInit() {
  }

}
