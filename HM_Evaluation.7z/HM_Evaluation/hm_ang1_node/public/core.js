'use strict';
var hmtestApp = angular.module('hmtestApp', ['ui.router','ngTable']);

hmtestApp.config(function($stateProvider, $urlRouterProvider) {
$urlRouterProvider.otherwise('/cart');

$stateProvider

    
    .state('cart', {
        url: '/cart',
        templateUrl: 'cart/cart.html',
        controller: 'CartCtrl',        
    })

    
    .state('productview', {
        url: '/productview',
        templateUrl: 'product/productview.html', 
        controller: 'ProdCtrl',       
    });

});

