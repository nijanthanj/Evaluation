 angular.module("hmtestApp")
  .component("productImage",{
      template: '<img width="{{$ctrl.size}}" src="{{$ctrl.src}}"/>',
      bindings: { src: '@', size: '@' }
  });

  angular.module("hmtestApp")
  .component("formButton",{
      template: '<button class="form-control">{{$ctrl.text}}</button>',
      bindings: { text: '@'}
  });