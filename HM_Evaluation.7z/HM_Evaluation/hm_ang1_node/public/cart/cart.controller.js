(function() {
    'use strict';

    angular
        .module('hmtestApp')
        .controller('CartCtrl', CartCtrl);

    CartCtrl.$inject = ['$scope', '$state',  'NgTableParams', '$http'];

    function CartCtrl($scope, $state, NgTableParams, $http) {

    	$http.get('/api/list')
		.then(function(success) {
			$scope.cartlist = success.data;
		},function (error){
			console.log('Error: ' + error);
		});      
        
        var self = this;
		
		self.tableParams = new NgTableParams({}, { dataset: $scope.cartlist});
    }
})();
