(function() {
    'use strict';

    angular
        .module('hmtestApp')
        .controller('ProdCtrl', ProdCtrl);

    ProdCtrl.$inject = ['$scope', '$state'];

    function ProdCtrl($scope, $state) { 
		
    }
})();
