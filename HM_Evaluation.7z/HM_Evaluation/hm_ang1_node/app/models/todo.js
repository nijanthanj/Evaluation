var pg = require('pg');

module.exports = pg.model('Todo', {
	text : String,
	done : Boolean
});