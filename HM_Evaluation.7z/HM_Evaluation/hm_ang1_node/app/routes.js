
module.exports = function(app) {

	app.get('/api/list/', function (req, res, next) {
		      var cartlist = [{
							    prod_desc: "Product 1",
							    qty: "1",
							    tot: "200 SEK"
							  },
							  {
							    prod_desc: "Product 2",
							    qty: "2",
							    tot: "200 SEK"
							  },
							  {
							    prod_desc: "Product 3",
							    qty: "2",
							    tot: "200 SEK"
							  }
							];
	    res.status(200).send(cartlist);
	});
 

	// application -------------------------------------------------------------
	app.get('*', function(req, res) {
		res.sendfile('./public/index.html'); 		
	});
};