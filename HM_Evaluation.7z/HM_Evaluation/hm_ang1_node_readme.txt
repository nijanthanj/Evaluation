Angular 1 and Node JS combo

Execution steps:

1. cd hm_ang1_node
2. npm install // To install all dependent node modules.
3. node server.js
4. Open browser http://localhost:8080
